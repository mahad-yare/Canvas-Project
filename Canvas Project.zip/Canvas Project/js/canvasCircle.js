class DrawingCircle extends PaintFunction {
  constructor(contextReal, contextDraft, options) {
    super();
    this.contextReal = contextReal;
    this.contextDraft = contextDraft;
    this.color = options.strokeStyle;
    this.fillStyle = options.fillStyle;
  }

  onMouseDown(coord, event) {
    this.contextReal.fillStyle = this.fillStyle;
    this.origX = coord[0];
    this.origY = coord[1];
    console.log(this.fillStyle);
  }
  onDragging(coord, event) {
    this.contextReal.strokeStyle = this.color;
    this.contextDraft.clearRect(0, 0, canvasDraft.width, canvasDraft.height);
    this.contextDraft.beginPath();
    console.log(coord[0] - this.origX);
    let value = Math.abs(coord[0] - this.origX);
    this.contextDraft.arc(this.origX, this.origY, value, 0, 2 * Math.PI, [
      true
    ]);
    console.log(this.color);
    this.contextDraft.stroke();
    this.contextDraft.closePath();
  }

  onMouseMove() {}
  onMouseUp(coord) {
    let value = Math.abs(coord[0] - this.origX);
    this.contextDraft.clearRect(0, 0, canvasDraft.width, canvasDraft.height);
    // this.contextReal.beginPath();
    this.contextReal.arc(this.origX, this.origY, value, 0, 2 * Math.PI, [true]);
    this.contextReal.stroke();
  }
  onMouseLeave() {}
  onMouseEnter() {}
}
